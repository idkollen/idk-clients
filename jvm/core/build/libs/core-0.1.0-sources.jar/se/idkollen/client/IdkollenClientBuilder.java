package se.idkollen.client;

import okhttp3.OkHttpClient;
import java.time.Duration;

/**
 * Builder for constructing an {@link IdkollenClient}.
 */
public class IdkollenClientBuilder {
    private final String clientId;
    private final String clientSecret;
    private Environment environment = Environment.PRODUCTION;
    private String baseUrl = null;
    private String userAgent = "idkollen-client-jvm/0.1.0";
    private OkHttpClient httpClient = null;

    public IdkollenClientBuilder(String clientId, String clientSecret) {
        this.clientId = clientId;
        this.clientSecret = clientSecret;
    }

    /** Select the target {@link Environment}. Ignored when {@link #baseUrl} is set explicitly. */
    public IdkollenClientBuilder environment(Environment env) { this.environment = env; return this; }

    /** Override the base URL, taking precedence over {@link #environment}. */
    public IdkollenClientBuilder baseUrl(String url) { this.baseUrl = url; return this; }

    /** Override the {@code User-Agent} header sent with every request. */
    public IdkollenClientBuilder userAgent(String ua) { this.userAgent = ua; return this; }

    /** Supply a pre-configured {@link OkHttpClient} instead of the default one. */
    public IdkollenClientBuilder httpClient(OkHttpClient client) { this.httpClient = client; return this; }

    /** Build and return the configured {@link IdkollenClient}. */
    public IdkollenClient build() {
        String url = baseUrl != null ? baseUrl : environment.baseUrl;
        OkHttpClient http = httpClient != null ? httpClient
            : new OkHttpClient.Builder().callTimeout(Duration.ofSeconds(30)).build();
        return new IdkollenClient(url, clientId, clientSecret, userAgent, http);
    }
}
